package question3;

abstract class  Vehicle {

    public abstract double calculateTollCharge(double numberOfTolls);
    
}
