package question3;

public class Motorcycle extends Vehicle{

    @Override
    public double calculateTollCharge(double numberOfTolls) {
        return (numberOfTolls*1);
    }
    
}
