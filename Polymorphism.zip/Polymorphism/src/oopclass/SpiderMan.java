package oopclass;

class SpiderMan extends SuperHero{
    @Override
    public void attack() {
        System.out.println("Light Attack");
    }
}
