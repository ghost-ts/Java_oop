package oopclass;

public class DriverClass {
    public static void main(String[] args) {
//        Calculator obj1 = new Calculator();
//        System.out.println("First Method.");
//        System.out.println("Total = "+obj1.getAdd(10, 30));
//        System.out.println();
//        System.out.println("Second Method.");
//        System.out.println("Total = "+obj1.getAdd(10, 30, 20));
//        System.out.println();
//        System.out.println("Third Method.");
//        System.out.println("Total = "+obj1.getAdd(30.4, 20.6));

        SpiderMan spiderman = new SpiderMan();
        spiderman.attack();
        
        Hulk hulk = new Hulk();
        hulk.attack();
    }
}
