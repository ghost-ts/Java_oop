package oopclass;

class Hulk extends SuperHero{
    @Override
    public void attack() {
        System.out.println("Heavy Attack");
    }
}
