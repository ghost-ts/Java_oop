package oopclass;

abstract class SuperHero {
    public abstract void attack();
}
