package activity;

abstract class Customer {
    public abstract double calculateDiscount(double purchaseAmount);
}
