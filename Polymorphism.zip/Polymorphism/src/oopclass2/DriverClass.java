package oopclass2;

public class DriverClass {
    public static void main(String[] args) {
        Car car = new Car();
        car.speedUp();
        
        Bicycle bicycle = new Bicycle();
        bicycle.speedUp();
    }
}
