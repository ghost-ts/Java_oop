package oopclass2;

public class Bicycle extends Vehical{
    
    @Override
    public void speedUp() {
        System.out.println("Top Speed = 150KM/h");
    }
    
}
