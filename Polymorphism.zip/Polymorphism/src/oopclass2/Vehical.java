package oopclass2;

abstract class Vehical {
    public abstract void speedUp();
}
