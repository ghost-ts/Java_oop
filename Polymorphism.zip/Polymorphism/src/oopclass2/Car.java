package oopclass2;

public class Car extends Vehical{
    
    @Override
    public void speedUp() {
        System.out.println("Top Speed = 200KM/h");
    }
    
}
